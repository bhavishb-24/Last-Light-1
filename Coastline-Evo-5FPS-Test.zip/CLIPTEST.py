from ti_graphics import drawImage
from ti_system import get_key
from ti_draw import set_color, fill_rect, draw_text
from time import monotonic

def run():
    set_color(20,20,30)
    fill_rect(-1,-1,321,211)
    set_color(255,255,255)
    draw_text(12,188,"5 FPS TEST   CLEAR cancel")
    longest=0
    late=0
    start=monotonic()
    for frame in range(10):
        if get_key(0)==45:
            return
        name="CLIP%02d"%frame
        draw_start=monotonic()
        try:
            drawImage(name,48,52)
        except (ValueError,OSError,MemoryError) as error:
            print("Could not draw",name)
            print(error)
            return
        now=monotonic()
        longest=max(longest,now-draw_start)
        deadline=start+(frame+1)*.2
        if now>deadline:
            late+=1
        while monotonic()<deadline:
            if get_key(0)==45:
                return
    elapsed=monotonic()-start
    set_color(20,20,30)
    fill_rect(-1,-1,321,211)
    set_color(255,255,255)
    draw_text(12,46,"10 frames / target 5 FPS")
    draw_text(12,80,"Slowest draw %d ms"%round(longest*1000))
    draw_text(12,114,"Late frames %d / 10"%late)
    draw_text(12,148,"Elapsed %.2f seconds"%elapsed)
    draw_text(12,188,"ENTER or CLEAR exits")
    while get_key(0) not in (45,105):
        pass

run()
