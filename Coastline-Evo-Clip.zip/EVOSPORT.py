from EVODATA import *


def fishing(s):
    target=int(s['clock']*3)%7
    bait=3
    pulls=0
    tension=0
    last=0
    hooked=False
    while True:
        title="FISH ON / %d of 5"%pulls if hooked else "SUN PIER / FISHING"
        hint="Alternate LEFT and RIGHT" if hooked else "Line up bait with gold"
        footer="DOWN slack / CLEAR leave" if hooked else "ENTER hook / CLEAR leave"
        sheet(title,(hint,),footer)
        if hooked:
            label(MILK,12,113,"Tension %d / 6"%tension)
            box(PINK if tension>=4 else MINT,12,125,35*tension,8)
        else:
            for i in range(7):
                box(GOLD if i==target else BLUE,12+43*i,100,32,7)
            box(MINT,12+43*bait,112,32,5)
        key=keywait((LEFT,RIGHT,DOWN,OK,EXIT))
        if key==EXIT:
            return
        if not hooked:
            if key==OK:
                hooked=bait==target
            if key in (LEFT,RIGHT):
                bait=max(0,min(6,bait+(1 if key==RIGHT else -1)))
        elif key==DOWN:
            tension=max(0,tension-3)
        elif key in (LEFT,RIGHT):
            tension+=2 if key==last else 1
            if key!=last:
                pulls+=1
            last=key
            if tension>=6:
                tell("LINE SNAPPED",("Press DOWN to give it slack.",))
                return
            if pulls==5:
                earn(s,18)
                tell("CATCH AND RELEASE",("Fish released / Tag fee $18",))
                return


def pool(s):
    aim=3
    score=0
    for target in (1,5,2):
        while True:
            sheet("VELVET CLUB / POOL",("Line up with the gold pocket.",
                  "Sunk %d / 3"%score),"LEFT/RIGHT aim / ENTER shoot")
            for i in range(7):
                box(GOLD if i==target else STEEL,16+42*i,122,27,5)
            box(MINT,16+42*aim,137,27,5)
            key=keywait((LEFT,RIGHT,OK,EXIT))
            if key==EXIT:
                return
            if key==OK:
                if aim==target:
                    score+=1
                break
            aim=max(0,min(6,aim+(1 if key==RIGHT else -1)))
    prize=score*6
    earn(s,prize)
    tell("POOL RESULTS",("Sunk %d / 3"%score,"Prize $"+str(prize)))


def palm_garden(s):
    sheet("PALM GARDEN",("UP gym workout", "RIGHT play mini golf",
          "DOWN clues for lost records"),"CLEAR leave")
    k=keywait((UP,RIGHT,DOWN,EXIT))
    if k==UP:
        gym(s)
    elif k==RIGHT:
        golf(s)
    elif k==DOWN:
        tell("LOST RECORDS",("West of Kiln Yard.","South of FM Tower.",
                             "Southwest of the Lido."))

def gym(s):
    for i,move in enumerate((LEFT,RIGHT,LEFT,RIGHT,LEFT,RIGHT)):
        sheet("PALM GARDEN / GYM",("Cycle %d / 6"%(i+1),
              "Pedal "+("LEFT" if move==LEFT else "RIGHT")),"CLEAR leave")
        k=keywait((LEFT,RIGHT,EXIT))
        if k==EXIT:
            return
        if k!=move:
            notice(s,"Workout stopped / Try again")
            return
    s['fit']=s['clock']+30
    notice(s,"Cardio boost / Faster walking")

def golf(s):
    power=3
    sunk=0
    for distance in (2,5,4):
        while True:
            sheet("PALM GARDEN / MINI GOLF",("Hole %d / 3"%(1+sunk),
                  "Match power to cup distance."),"LEFT/RIGHT power / ENTER putt")
            for i in range(7):
                box(GOLD if i==distance else STEEL,15+42*i,119,30,6)
            box(MINT,15+42*power,133,30,6)
            k=keywait((LEFT,RIGHT,OK,EXIT))
            if k==EXIT:
                return
            if k==OK:
                if power!=distance:
                    tell("MISSED PUTT",("Try the course again anytime.",))
                    return
                sunk+=1
                break
            power=max(0,min(6,power+(1 if k==RIGHT else -1)))
    earn(s,15)
    tell("THREE HOLES CLEARED",("Course prize $15",))


# Two keyframes from the opening. Each pair of symbols stores three pixels.
CLIP=(
    (((212, 199, 186), (207, 151, 140), (158, 156, 164), (116, 155, 169), (187, 112, 125), (144, 107, 121), (111, 105, 136), (77, 104, 131), (139, 76, 89), (88, 75, 105), (121, 54, 85), (84, 47, 75), (57, 63, 97), (49, 39, 68), (38, 16, 42), (14, 1, 30)),
     '/////////////////////////////////////////////////////////////////NTyp7Tt'
     'TtVCwvcPcPbbMExkwuPMcPbhibLLTtTdTsPcTtTtTtwehlwxgggggeZV/3DtTpCpCtVCwI8Y'
     '8Y8Y5Bk8LH4H8Y8AK0000pCoCpCo8YCpCor1ZhleH1H4H46//3TynpCtpTp7sIPbGH4K54I4'
     '1H529IGQa0020Y0pCZCp92Cp8bv4M8Y+WHH4H46l/3CtTpTtTtCpoXH5P4KH4KYh454K9IGQ'
     'a0000200CpCoCo8YIDv4MkjTv1H4H46l/3CtV7CpCpCpoX4HAVzH4RggW54H514QaY82chaW'
     '02CaGHGKh3r8sxiIfKH4GH6l/3CykMCpCpCpco4HZkkxX4Y4WG4HGH4QK3RDkAiY8ikxkwf4'
     'Oor5Y8Y1Yq4H516l+JDtnsTtSpCpoIGO/QhU/eMeX04H4H4Oa0dSbL820YOpCpQe8pr1IxY0'
     'la4H4H6/+JCpCtpNTpCpcYGTwAlkYhggGH0H4H4Oa02TtSSW02TZCpCaKpr1Meg1lek14Kdl'
     '/3Cp8zpCTtCpcXHTshxeI8Y8HK004H4Oa109tSnp82PdCpCpOpqHIhkuxhjH5Cxl/JCY8ztC'
     'nySYUXM+sAv4kq6hgeXI0148m042dCpTaW0ZPZCpCpr1LUwukxkwNUlV/J8Y8fx7pCxMcGJg'
     's8GLke4Qk8YT804OmW009ypCns009cCpDcr2PbhPLOc6thMl+J828cdDrvpTwHNjtgH8Y44L'
     'g8R9L108mp800ddCTySW03OpDtrcdPczbLnisR6F+IPI8YPdPY02kHg+/gL8Y15LI5cQY8K8'
     'mpCp8WASnyp3008pCpqstCoRwBcUrHM/+J8yK2MrKW00QXgk/eg8g1A8WccjY8iLmpCpDt8i'
     'tCpCC003CprYdSsRxPbLkX2/+I82PILP4100c0Yz/egwWG9L8cMgY8f5aZCpCtTsVDtCTW00'
     '8prZAUxPcPObgN2F+I9I0tbY0Y4Yc0NUsAY8fLPdQRH8YAkfrdTtTypCp9pToSS00prZCvtP'
     'ahbbLdAV+I8cC2UJ8Y4Ic0hhHKWOrfcPbif8gycPcPRSQPcPdNTvcPcL8ZrJOoRTQUjYLcAV'
     '+I8YPW1x8Y4Ic0hbeKY1itTtTpsAkpTtTtEpTtTtENTtTsPdTpsMCpRPdkrY9MRF+I8X8c9i'
     'OY8Yo0XKKKYXbdpCp7dbsNpCTtdsaiTyV7TtTpCpCpsMOrt5lj+IMbRF+I8Y8YcTaY8oc055'
     'KKYa2pTtUM9MKcbLbbMs89PyQNDtTpCpTtsPPOrelkwLgvRF+ICYCY9f8Z8Yo0H5KKIA6MPc'
     'QG020080800W09PfQTtTtUxkxkxCYhjRxjwPkMVV/28W8Y8Y8Y8Ic0L5X4IAXBQMQG8200aW'
     '820W89PcQRbLdUxkxRwwPOk+xkx7Tu6V/jtTsxpCp9cMs0X5jQX8YDPcQW820080820W8APc'
     'MLGItjxksxuY9OljtUtSPkM/+aXKHLY8YAggrHY8czv4gAj5IW020W80820W0AHQIL4Ixkxj'
     'kPqp9htPVExUayxl+uf44H4H4H4Hg1YfcTwqI8rKIc020WKggggvggf4IL45kxkeYOrZCxjt'
     'T+xDsTtV/OYejLGX4H4Hg1YfcRth68gKIY0fAM05gIMrLPMgIK4OgAgeY5rfaibsPzwMtTtl'
     '/L9B/lWX4H4HY1YAcRtUf8ZLH8Yb0280800W0Y02MKKeggkwHOwSpCcMcRxMdjtl/2M+kkw1'
     '4H4HY1X8gPtUwaYfH4H50Y82800W0b0YMLjLgggbHOxTtTtTxkxkxlxl/2hhgB+n4H4HXHY8'
     'kPtkxxk+H4H50W80809GMb0WMetkkzxQI4rcPcPcPcPdcPdV/5tegBwn4H4HZRxkxktTtTpD'
     'aKH800828W1GX502Mek+xl/vYevcPcPcPcPdPcRF+uwuggxb4Y8XZNpCp7ncPcPcqKH89PPc'
     'PccIQ8XQIKZCljpBfQvcPcPcPcRDbcRF+x+qg8/e4I8Yd6p9pCoMPcPpcHI0020W00K024H4'
     '6KHLIzpRXQrZPcPZPcQUafFF/U/gfT/e4Y8YdNVCpCncCsp7QnIY020282K224H46O4Xhhkg'
     'IBrZPZDcPcd9XMFF/k/hhVxh4b52dNd9dCncDipC6660020Y8W8224H46I4IlkkgZRqspCPl'
     'gykrjIBF/StOh//+Kb9YdNpCcNTc9ibr5B600202808024H46eYcYhtksxrjbikVLBOW8YAV'
     '/NpBhl/kKX9Yd3pCp7TcPcPX5AL59P8fObbYM4H46gYPkxlkkzrjdSt/f29I8YAV/NTykh/x'
     'X28GZMTcV7TcTsTGH4iKIo8Y8YALH4H46k4kNUtjtkvjtDt/gb95sIAV/STcYNpUjI8HZJoN'
     'PcPdTtO1H5nHXW8Y8YAK54H46h4kk+czkwucxklkgYOSt22V/STs0ISoj28HZ3oPcMOsbt84'
     '68pGiY8Y8YAK4KH46kYhjLYgkevsR6QwLIKfrpFF/Sns9Y8WXH4HZ3PcUNbrYK51I5phOY86'
     'CbMH4H4H6glQYBkxkwxCcPsxifbbrZFF/ip69fToXHH1hMTvoxcKY4X4I7pD8Y84GTkxkxkx'
     'lhsPYeYBkwx7V9dRjYp9nZFF/hcx9IPojHOXZOY8H14HM4H4XMp21RaHHTtPdDtgxjoPgAIB'
     'YBvtTtUPPcsyp9VV/jkxkbPpWHOaYXI74G08s5H4j5sGM+sPkxcPPfpQwvcPYhHAZhvtTsOu'
     'LcpDtPVV/jk8ggkIDbOegvoI010ksgX8vRsIgvkPbPPhQPthkPcLIhW8kxx7TsKYXMpCtTRF'
     '+yr4Y8YecwPQkKGH4H6EwxjEkBsI8YgxcxcBQSpkoPcOIAiQkwvpDcUIQgcSbzdF+rrKY8YA'
     'kwnacqY8GH6jswX8MioI8XggghfPRDtzcPcRY8kBkeuY8YOpQRwSmvdV+IgaY8YegbPXZ///'
     'aH6zsq55YvoI8beKYAIPPsRicPcPk9dDk8wPbJp2Cjx7rjpV+HLbYeYef14HYwx/wqJTs1ZT'
     'tMp28a4KIbLcOoBTpCcPcPcPkAxCPsdMCyx9btVF+X5bMeY8eG4HZwYkxhtksDxTovoG8XI8'
     'LI8YDYBUpCoPcPcSkAx9TcpPUTt7PpFF+HHLYAggY14HZ+xUxl/+lTt9cysG4Y8bCo8Y003T'
     'tCcPcPpCkgvtTtbtTyzoapFF+I9OY8LIMX4HZ+x////jkPc9YPsI8YCpCo8Y003ScPcPcPcS'
     'k8uo8YCpCpdSSpFF+rchkxPckwM5l///xktTtRkzkzwsQPcPcNUPLLNjtTtTtTtTwxwPcPcP'
     'cPQStSpV////////////////////////////////////////////////////////////////'
    ),
    (((253, 253, 254), (253, 248, 226), (248, 243, 231), (228, 240, 243), (240, 217, 229), (243, 210, 169), (219, 209, 215), (191, 207, 235), (227, 184, 162), (226, 161, 113), (167, 176, 199), (164, 155, 171), (200, 132, 93), (133, 132, 152), (174, 99, 62), (97, 83, 61)),
     'fsQggdPtTtCtTtTtTpCm0000000000000000000004M98pZCbOG002QgTcPcQgghfwggggTt'
     'DtTtTtSpCm0000000000000003C00000015PKHN9MPK0001cH4PcQggjggggggStDtTtTpCp'
     'Cm00000000000m1H03C0000001KHKG1H0HK00H4Y8aHcQggjgdPwgdTpCtTtSpCpC0000000'
     '000000790003C300024L40015LK0014H4I9cQgggPsPcTtTdSmHtCpCp000000000000KGdi'
     'K58pCp00001L5HLLNEK0008H4Hp/t+kzTtPZDq0cSm17CpCZ00000000000Zd5pkcS93Cm03'
     '045HdiwSdkK0000X45p+dCpEPjP6To01OW04CpLL000000014H0Pd9xEd9bJOX40CubLp6bP'
     'pfK0000001cFLOp9RU86O0000000CrbP400005cSpCcPoSxkoPoPpEoPKHMCaGbLdf400000'
     '0WLSvLNC/x0c80000003C5p900006UxkxkxkdCpkp9dkxkxkx9MEbPxip9KW000000BEbLp+'
     '/54H4H4G4H4H4Pxq00LLpltTtTtEwUxkwSxjtRtTx+bLcUx+p9WH4H4H4H6EdCpipCoPcPcP'
     'cPcPdCxc006SxTshfglT/ixkxFvwQgggtUwP0UxkpfcPcPcPcPcPdCpC/TtTtTtTtTtTtTpf'
     '00JCo6ggPhlRpkxkxkYggsPcgDxCLU/ipTtRsxoSxjtTtT/ztTtTgggggggggjpEbPp9nLP6'
     'gggvNioSpfdTjaHcLPoSxkxfkgTtfdTbMwgggjhTgggdTtTtT5TtTwgCxicud9HggggxoRfg'
     'kPc9WW0aYScxpioMTtT003C14Rf7UgUjTtTtCpC00140CtIhkxfcQ4HcUggxkxgcOq04L004'
     'PLQgguksH00000000LPpTtEjTtSpTp0000801tIgggf2Oq8aIggxkxgzH8G1K000PaPcIgQg'
     'H000000000DpCtUxTtCpCp00000G1qPsPgSaH6PcgztTkwh/X4GeG000A6HaHcPcGa000000'
     '00Cm1wUdTtTpCm00000H0qPaP2HaIhkxkxsxkxl/H22Cba801hP2PdP6Oa00000000000tCm'
     'TtTpC00000014aPcPa9aIgkxkxkgggt/icI9p9X01hf6PtH4P200000000000703TpCm00G0'
     '000056P6HcP2QxkxkxggPa//zcPgkuX01BP7T2H2PZG000009W028303qpD88gO00000D6P6'
     'TsGagxkhswgwDc//P4QwfpXW1eKKPcH4Pa8000001hHO4006zZ1glRf0HcG0D6H6HcPckxkx'
     'kwggHc/zHalQf0Q016LKPp9cPaG00002YzwsO31e/KQw/OtRtTs0D6HcH6RTkztRkwggPA/s'
     '9hlTsaX01c4LHaPtH0Qs0006oS/MXglTxxjzrelztztu94H7TZhTtTjaH6Qg1A/KQxtTkxX0'
     '1b4LH6D6GYBu8008tFQxFT/T/xYxC2ZztTMR9aHdColTtM8000IZDqgqQxlRgxG0I6KL548a'
     'GcBe00HeYO0hQz/z/Rgh82ZVdDLL94HtOYlTrW00001a142cRRfcgu80QwPcP28aHaA40eXO'
     'XG0m2xtzkxkjK4ZSdCLH94Ha8akzO00002I617UxQt06kK00YaHAf2H4PcGW1jYDiWA8pEpR'
     'lRkxO4R9cLLL96PaH4hR00HG04M8IjtTgZ14YG04faH6f4GYP49Y2jsCi8pkxkxktTtTk6YP'
     'cLN8HaP4H6ks04p8G244IjtTgc14bW06PaPcH4HcP4AzQ/rBkPpipixktTlRZLYPcLdMHaTq'
     'TctK08syb400IhtTjc08a016PaPc0aH6H6A//VsxtbM5Z8dCtV/slMYPoPtuHaP4TctK08kx'
     'dCG0IhtTscTCO014PaHa16H6P6BVtTtTt5QBY8MS///usuNFwRtuHaH4PctK08kxYCX8IjtT'
     'swku80H4HaHa16TtH6BVtTsBtkxk//pC/jkB+CRF///v9aH2HctK08kcX6P8HjtTswl400L6'
     'PcHc1cHtH43l//+8l//k////pTtVZCZ////+HqH4H4ks06b4P4H4HjlTswc004XckcPc1dTt'
     'PctyYV+DZF/l////X6Y8N+p/xlx+Ha94H6gu02c5XgP0Zwgckxn006k4PcHaHcTtHD+mQ/+/'
     's9xl////lEwP/ull////PcH48aQxG0ILHhfe/wj1Yxb00eY406kgP2PaHDmh//wBsLx/////'
     'x////eZV////XcH4PtUxW029A6l/+xOHMyW01BX2H4gwP294Hc0E//w8tidl//////tTsuYz'
     'tTtVidH6TpHjj008Xat/sjOKQvG01jGcY8hMPsP4PYIExTjel+xUtTtzx/xkxixkxkxkucH6'
     'PaHAXI02c4t/IBQglPG02BXcPePcOcPaPcc6xkxEx//zxlx/xkxkxkxkxkxkvKH4P4OsY400'
     'IO/uPhRTtO00AxkxkxjcP4TcOuK0RkxkxiYyxkxkxkxkxkxixkpEx2P0GYDtQ8G02C/MkhlT'
     'tO00IxkxlTja96P6PEW01jxCbYt/xkxktSp9pDtTsxkyp4OYH4PdU8X009XhkxtTt800JRsx'
     'tRPtH6HcHka00tOW0b//tTtToPcPcPdCpTtUpeH4H4M8Y8LK04oBXhlTt800QxtTsxggfsHc'
     'BEmW03CpQcB//TtTcPcPoLLLLOpCbK8aH4H4M9c8P4ZBXOlTkLG0YxkxkxkxfqPYNkn003Pc'
     'lzA//T/RcPdEwLLH4H5L8aHa94MPpkxCoQYScPkwYPaakypExkcPkcP2pinG0WDx/RBV/Tsg'
     'cPpknLLHLH5L54GWI9dkotTsd9cyxhsxlEbecPkgfepicRf9/kx000QzszAl//tTxkxkbLLH'
     '4H5LL4G4YPxdTtTsY8YSxjtThkcPLLXdC3EEwPk9pCxiOA/z/TXj///////ybLLH4H4HM8H8'
     'cUrtTtU9TtTupktTtkb003YJ07SsxfX4H4ZEYl////+l///////yLLLLLLKH6BlSdkftStUS'
     'LtSpZExkx980CpZ103Tthicggggxl////////////+xfLLLLLLKHNEpiphTtSpUEbtgL9Pxk'
     'nL6LCop20tfxRkdipCpCpExExkxkxkxk/kpfLLLLLLLL5effpkcQTtSwfwheNCdfp9N9CpPt'
     'TwgPpynMPcPcPcPcY8YBYxkSxkxfLLLLLOLL5tfupkcPftTwUdE9dfReNiM3DtTtTtkLdimt'
     'TtTtTtggggggggtTxkp9LLLLLLLLPtfspCcPgggggZCpcMNfDP8pDwggTtV9dEbtTtTtUdgg'
     'gggwghlTxSpCcPY5LLLLPtgdQSp7TtTtfpDwfpELCpCpDtgggdUypBftTtTtgggggggggwkz'
    ),
)
CLIP_CODES="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz+/"

def clip_frame(palette,data,deadline):
    offset=0
    for row in range(54):
        run=0
        previous=-1
        for x in range(96):
            slot=x%3
            if slot==0:
                pair=64*CLIP_CODES.index(data[offset])+CLIP_CODES.index(data[offset+1])
                offset+=2
                pixel=pair//256
            elif slot==1:
                pixel=(pair//16)%16
            else:
                pixel=pair%16
            if pixel!=previous:
                if x:
                    box(palette[previous],16+run*3,12+row*3,(x-run)*3,3)
                run=x
                previous=pixel
        box(palette[previous],16+run*3,12+row*3,(96-run)*3,3)
        if get_key(0) in (OK,EXIT) or monotonic()>=deadline:
            return False
    return True

def intro():
    start=monotonic()
    deadline=start+20
    box(INK,0,0,320,210)
    label(MILK,16,201,"ENTER skip / 20-second intro")
    shown=-1
    while True:
        if get_key(0) in (OK,EXIT):
            return
        elapsed=monotonic()-start
        if elapsed>=20:
            return
        index=int(elapsed//10)
        if index!=shown:
            if not clip_frame(CLIP[index][0],CLIP[index][1],deadline):
                return
            box(STEEL,16,180,288,5)
            box(MINT,16,180,144*(index+1),5)
            shown=index

def front_menu():
    from EVOVIEW import person
    intro()
    settings=[False,1,True]
    items=("New story","Load save","Settings","Quit")
    selected=0
    while True:
        skyline(7)
        box((51,91,121),0,84,320,53)
        for x in (149,194,242,287):
            box((123,146,174),x,100+x%9,23,2)
        box(VIOLET,0,133,320,77)
        box(STEEL,132,138,188,3)
        for x in (147,219,291):
            box(STEEL,x,138,3,59)
        person(193,190,121,MINT,0,False)
        person(258,190,133,BLUE,0,False)
        box(INK,0,0,133,210)
        label(SUN,8,27,"LAST LIGHT")
        label(MINT,8,48,"COASTLINE")
        for i,item in enumerate(items):
            y=72+24*i
            if i==selected:
                box(PINK,4,y-14,3,15)
            label(MILK if i==selected else STEEL,10,y,item)
        label(MINT,8,181,"CLIP HD")
        label(MILK,8,202,"ENTER select")
        key=keywait((UP,DOWN,OK,MAP,EXIT))
        if key==EXIT or (key==OK and selected==3):
            return EXIT,settings
        if key==MAP or (key==OK and selected==1):
            return MAP,settings
        if key==OK:
            if selected==0:
                return OK,settings
            menu_settings(settings)
        else:
            selected=(selected+(1 if key==DOWN else -1))%4

def menu_settings(settings):
    row=0
    while True:
        labels=("Graphics  "+("Full" if settings[0] else "Fast"),
                "Turning   "+("Fine","Normal","Sharp")[settings[1]],
                "View      "+("3D" if settings[2] else "Top-down"))
        lines=tuple(("> " if i==row else "  ")+item
                    for i,item in enumerate(labels))
        sheet("SETTINGS",lines,"ARROWS change / CLEAR back")
        key=keywait((UP,DOWN,LEFT,RIGHT,OK,EXIT))
        if key==EXIT:
            return
        if key in (UP,DOWN):
            row=(row+(1 if key==DOWN else -1))%3
        elif row==1:
            settings[1]=(settings[1]+(-1 if key==LEFT else 1))%3
        else:
            settings[row]=not settings[row]
