from EVODATA import *


def fishing(s):
    target=int(s['clock']*3)%7
    bait=3
    pulls=0
    tension=0
    last=0
    hooked=False
    while True:
        title="FISH ON / %d of 5"%pulls if hooked else "SUN PIER / FISHING"
        hint="Alternate LEFT and RIGHT" if hooked else "Line up bait with gold"
        footer="DOWN slack / CLEAR leave" if hooked else "ENTER hook / CLEAR leave"
        sheet(title,(hint,),footer)
        if hooked:
            label(MILK,12,113,"Tension %d / 6"%tension)
            box(PINK if tension>=4 else MINT,12,125,35*tension,8)
        else:
            for i in range(7):
                box(GOLD if i==target else BLUE,12+43*i,100,32,7)
            box(MINT,12+43*bait,112,32,5)
        key=keywait((LEFT,RIGHT,DOWN,OK,EXIT))
        if key==EXIT:
            return
        if not hooked:
            if key==OK:
                hooked=bait==target
            if key in (LEFT,RIGHT):
                bait=max(0,min(6,bait+(1 if key==RIGHT else -1)))
        elif key==DOWN:
            tension=max(0,tension-3)
        elif key in (LEFT,RIGHT):
            tension+=2 if key==last else 1
            if key!=last:
                pulls+=1
            last=key
            if tension>=6:
                tell("LINE SNAPPED",("Press DOWN to give it slack.",))
                return
            if pulls==5:
                earn(s,18)
                tell("CATCH AND RELEASE",("Fish released / Tag fee $18",))
                return


def pool(s):
    aim=3
    score=0
    for target in (1,5,2):
        while True:
            sheet("VELVET CLUB / POOL",("Line up with the gold pocket.",
                  "Sunk %d / 3"%score),"LEFT/RIGHT aim / ENTER shoot")
            for i in range(7):
                box(GOLD if i==target else STEEL,16+42*i,122,27,5)
            box(MINT,16+42*aim,137,27,5)
            key=keywait((LEFT,RIGHT,OK,EXIT))
            if key==EXIT:
                return
            if key==OK:
                if aim==target:
                    score+=1
                break
            aim=max(0,min(6,aim+(1 if key==RIGHT else -1)))
    prize=score*6
    earn(s,prize)
    tell("POOL RESULTS",("Sunk %d / 3"%score,"Prize $"+str(prize)))


def palm_garden(s):
    sheet("PALM GARDEN",("UP gym workout", "RIGHT play mini golf",
          "DOWN clues for lost records"),"CLEAR leave")
    k=keywait((UP,RIGHT,DOWN,EXIT))
    if k==UP:
        gym(s)
    elif k==RIGHT:
        golf(s)
    elif k==DOWN:
        tell("LOST RECORDS",("West of Kiln Yard.","South of FM Tower.",
                             "Southwest of the Lido."))

def gym(s):
    for i,move in enumerate((LEFT,RIGHT,LEFT,RIGHT,LEFT,RIGHT)):
        sheet("PALM GARDEN / GYM",("Cycle %d / 6"%(i+1),
              "Pedal "+("LEFT" if move==LEFT else "RIGHT")),"CLEAR leave")
        k=keywait((LEFT,RIGHT,EXIT))
        if k==EXIT:
            return
        if k!=move:
            notice(s,"Workout stopped / Try again")
            return
    s['fit']=s['clock']+30
    notice(s,"Cardio boost / Faster walking")

def golf(s):
    power=3
    sunk=0
    for distance in (2,5,4):
        while True:
            sheet("PALM GARDEN / MINI GOLF",("Hole %d / 3"%(1+sunk),
                  "Match power to cup distance."),"LEFT/RIGHT power / ENTER putt")
            for i in range(7):
                box(GOLD if i==distance else STEEL,15+42*i,119,30,6)
            box(MINT,15+42*power,133,30,6)
            k=keywait((LEFT,RIGHT,OK,EXIT))
            if k==EXIT:
                return
            if k==OK:
                if power!=distance:
                    tell("MISSED PUTT",("Try the course again anytime.",))
                    return
                sunk+=1
                break
            power=max(0,min(6,power+(1 if k==RIGHT else -1)))
    earn(s,15)
    tell("THREE HOLES CLEARED",("Course prize $15",))


# Ten frames sampled from the supplied opening, with two 3-bit pixels per character.
CLIP=(
    (((196, 163, 159), (132, 148, 159), (161, 106, 117), (98, 102, 129), (128, 69, 88), (84, 60, 89), (56, 56, 89), (44, 24, 54)),
     '+/ss/sts/zktrksssst//t//vR9Us900aG12009999BKlGI7vRPPB0L0a02282819GbKaYI7'
     'vTR9B0/zaG029qW3RKBKWg07v9sPB4jyaG028Un1P9B2izGlv1ssR7iKIaO2O3sO39BIjbbl'
     'v8EpTNwK2Zg0P0Es89BUjirNv9J02NyY2JaYPBBsn0BBzhT7v9P03NYaRSKjRRpssOBPUTBE'
     'v1BOBKIJRTbRRhRRRBBPT/IVv1B9B2IYRP8998RUUsspi/TVxRRRR2YKRO0000RSN//Qd/pV'
     'yYIIKKlIgG10IHYW7zb9jVptwbW02KUwYIH8G9AYKaLrpVl/wzw02Kj/bIG0000bjyLrjkkt'
     'ziy05ssrTIG99AGK/+bPRRhV/iz15UsPRQG010II5zbRBRqF/z/ILUsPpK0000IKLzkTUbHF'
     'xT/G5RRRO4I99IIKb/+k/XJ6xQRW4RRR8KI99GIKbjjUjXUF+P9G5RjKILn8CYYdiblpkRhF'
     'ziRGCaG4ILQoUjt+SadRRLsV+KaSSG0dabQbiZthaYlPPbslxKaZD/GkIcOIaZlTibaPRFpl'
     'uKaG5/yzdrOII9FrjkdpjVhVuKYG5//+rc89806rjkdP9DhF+/+/l/////+ssrl////sss//'
    ),
    (((196, 163, 159), (132, 148, 159), (163, 107, 118), (100, 103, 130), (128, 69, 87), (86, 61, 89), (60, 61, 95), (48, 28, 56)),
     '+/ss/ssj/zkljksskssl/jjlnpBUs900Y0120019893IdGI5nR9PB0L0a22282G19ILKgYI5'
     'nTR9D0zzaG029zW3RSBKYY05n9sPB5jyaG028Vn1P9BIyzGlv1+sRNiKKaO2O3sO1PBIjTbl'
     'n8UPTNwK2Zg0P0Es81BUjjrLf9J02NyY4BaYPBRsn0BRzhL5m9P02NYZRSKjRRpssP3PVTBD'
     'n1D8BK2JUTbRRhRRRBBPTlQUn1B9B2IYRO8998RUssspi/jUxRRRS2YKRO0000RSN//Qd/pT'
     'yIIIKKlKgG10IHYW7zbPkVztwbG02KVwYIH8G9AYKaLrpVl/ozw02Kk/bIG0000bjzLsssst'
     'ray05s+sUIG99AGK//bPRPRV/iz25UsPRQG010II4zbRBRqE/l/2LssPpK0000IKLzjTUbHE'
     'xr/HDRpRO4I99IIKb//k/XB6xQTW5RRU8KI99GIKbjjUtXUE+P9G5RjKIMn8BYIdiblplRRE'
     'zgRGKaG4IMQgUjt+SadRRJ+VzaZZaG0labQjjZthYYlPPLsliKahDjG/IcOKaZlRibaPRFpt'
     'gSaG5/yzdsOII9FrksdpkVpUeKYG7//zrc89806rjkdPRDhEz/szl/////sssrl////rss//'
    ),
    (((0, 0, 0), (), (), (), (), (), (), ()),
     '000000000000000000000000000000000000000000000000000000000000000000000000'
     '000000000000000000000000000000000000000000000000000000000000000000000000'
     '000000000000000000000000000000000000000000000000000000000000000000000000'
     '000000000000000000000000000000000000000000000000000000000000000000000000'
     '000000000000000000000000000000000000000000000000000000000000000000000000'
     '000000000000000000000000000000000000000000000000000000000000000000000000'
     '000000000000000000000000000000000000000000000000000000000000000000000000'
     '000000000000000000000000000000000000000000000000000000000000000000000000'
     '000000000000000000000000000000000000000000000000000000000000000000000000'
    ),
    (((114, 112, 129), (55, 53, 73), (47, 44, 65), (45, 42, 63), (44, 41, 62), (43, 40, 61), (42, 39, 60), (40, 37, 58)),
     'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
     'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
     'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
     'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaacjjjjqaaaaaaaaa'
     'aaaaaaaaaQIIIIJaaaaaaaaaaaaaaaaaV800001xaaaaaaaaaaaaaaaabH9999Aiaaaaaaaa'
     'aaaaaaaaalt//+zaaaaaaaaaaaaaaaaaaZZZSSSaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
     'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
     'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
     'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
    ),
    (((213, 225, 190), (173, 168, 101), (181, 130, 65), (105, 130, 66), (147, 94, 50), (87, 89, 50), (89, 56, 34), (39, 35, 30)),
     '///H010005P9J1X00093g///k//X010001039BO000BBI//////fA90003O5Hr0000PBI///'
     '/qaHo10004G5oZ0000PQC/t//saHY100028Rkh80O13HC+///+aqY20001BRRhO3805vF///'
     '/yYtoC010098DfAR007+t////+YcoK0301P9VPBh00B//t///+acri8BB99OA9BjP99Bl/+/'
     '/+jYITQBiBAb891RP030BTk///iaKBh9CQHKIHBXTOB09RiLqt+aIRRHBQHKiZhITQBB9DjS'
     'IKsqYRKTBYILRRf1JTbRRhTkIDshRBRjTHKjRhAARgAZRPflIEzh9PBlhHIhhaCRRgBbhRT/'
     'aV+YZ9BhTYMO9FTRjhTjYbk/aUsIbADRUPcHB9R9krksIdqtcbsarIJBhhSAMPhAKRgKatss'
     'sktsyIHKhhSILiZhjbgK/+aasa//+qQZjBTRrKb+r/+siIacsajP9TRjpPjj/ctt//iIIaqt'
     'ssf990VrhRhkstzj+YHKssstqZTf995xhUaaal+qIIIacsstiaTf99PjjjbilzYIIaaacsss'
     'iba99BlTjttsaIIaYKaKaacssjX9JTljstsYIIaKaKaKbsssshAajj///qIKqaaKaaaaktst'
    ),
    (((223, 224, 90), (197, 201, 68), (189, 184, 66), (161, 175, 52), (155, 151, 47), (120, 143, 35), (107, 122, 27), (64, 84, 10)),
     '//+s+ZRStrR+RUqRJ0I1s+as//+rrZJbssZiRkjRQ0G2/ySi///jrQTat+rjktrcZ00BtnBS'
     '///krRTgLzsssqITh01RRRZA//+kqjb99SbibO92TYcBDkPJ//rkYTW09Kbri980JHTXVz1R'
     '/+rjj0099Lksj99095jXlv9Rt/rjk8099cq03O900MhJlfBR+zjjjX184qW00KR8AkhRlfJR'
     '+ojjrRI01a0004aH9kZRVf9RspbjrJH01a0004Z98BIZdn9JsnSTsSIILsXIYMsQIQRjavAB'
     'tO9DiLiLssZJYUrZ2aXDGs1r+ACrjLOKZsQAILi2G9gTjEyJrksskZKaKsPSILjZiRgUsrls'
     '+ZkrcaSYAsYRQbkrsshKrRRjX91krIGICj910CiIJIXJf19D999Mr9IH2j9804qIIKXB819M'
     'Q99EpbaZ1jQ004qIaaiR999VQI9EYkiAAig005baPKhH99HdRjP1Rh03Tsg98MsPRI9991Il'
     'RTt+tzijjjZRIRrG1RP99HQtxILt/////hHJrHI00Lh8AZJ/xJGCt////zYIcf0G81jP1RJ/'
     'yIASl+hIRt+Y0R0O08lY99K/zRSj/z084s/sW3AOG2lpIIb//hct/qs////+Y0f895//hSjt'
    ),
    (((254, 249, 237), (237, 237, 236), (237, 210, 198), (202, 204, 216), (222, 170, 141), (168, 167, 183), (171, 136, 128), (141, 101, 66)),
     'RjRRRP9000001002XKY0BQJjhjRBR98000041000G0I001LjRRBOP900002dY901Kaq004+s'
     'jB081K00Kaa/aaaIaay002qcw0000a04//y/d//ya/a000ad+ssss+0cjTl//jRlY/saass/'
     'jjhRTiaaJjirqo2atyRRQbTjR9801TjAHTjjI20ITh80019TR9001RRBRjjlHY0RBR80001P'
     'B8001IPBjjhtfcWDB9H00008eTf91HRTjjftJhIAJ9P00LW2xkstfJBjhRfsLjHAIBAW2shs'
     'zfNyYBBj81PRjjGRI1AOKWBsrnMaHJ3f12JjfC0PR9Q1sIs+srKaXPDecH3jfI2PPBHsrqcc'
     '/sMsn9TejaBjjX2Q9RH/s+tq+sd/x9DeYIIjjGIh9RD+yt//ctt/x9BeKJMgk8gBQRMU+q//'
     '//M/x9Rg2L+ei1fLh9Hdot//////+9PS0Mwjo3hjPRQM//t//s+s/HARG6jjo3jjPQK1iL//'
     'aaacqH9KaAajo5krhHd09h/sa+I2HHKcaaqjaKcaqQ/GDxtr/yIGIIdhRRdr/IJ1dYcpt+l/'
     '/wII4szPSRK/YHa3Uyac/////oIYIiyZRRaaaXRTdxRRTjjk/qYIJRaZRPSSABjRapRTjjjj'
    ),
    (((238, 214, 160), (208, 159, 109), (194, 122, 75), (132, 109, 87), (154, 64, 38), (102, 63, 48), (65, 53, 46), (41, 27, 28)),
     'URjTrH999U//Rktt////B/t/TRRRRG980Rk+jsVsstzsRss/ThBRQ9001URhjrtoIkRkhs//'
     'hPRR9800DsSRRRTO1iLlxs/ti9DO0808JjaYkjRO1JTkzUltjaA80811RTjIKtkhIJBksSj/'
     'aaa810101TiaIRlraXBkshrs9IaYG001AjJia9YBKHXksjks81IK80GCah1hPIX3aIIj+iaj'
     'P01I84WKbf299j80oAAijjaj+8018LgajP3YDte3HAHTJiba/x001jt+jG1PMsjhAAG3QSaR'
     '/+f0ILsjTO0BLPcqQI0RijaS/pUP82rRiX3sP0ZJ83RTRRaa/pbj8CjrYHV+O0L918Bk81KZ'
     '/rk+IE+iYHU/g1lW001PB9BT/jl+gtraHIs/zjaH8000R1AB+sIIgkaY1bl/ziIAG80001HB'
     '/zG2isaYAJTjjYIY90989BPBs+G2glgIKYTHLqaY0JSO9B9RrrQK9cg2KYk9LicXAMjjQJAR'
     'rkf905qIIPKIlqaXIaitzKabhj901NqHIYId/+aabrrk/rishP919L/fAKil/+rk/////++t'
     'hH990K/v0KKlzak/////st/+RRH91b/zIabtabt///sRRRTkRRR9Ts/sl/+zk/////hRPRRU'
    ),
    (((69, 65, 83), (47, 43, 64), (45, 42, 64), (44, 41, 64), (44, 41, 62), (43, 41, 62), (44, 41, 61), (38, 35, 56)),
     'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
     'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
     'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
     'aaaaaaaaaabjciaaaaaaaaaaaaaaaaaaaaX9ATaaaaaaaaaaaaaaaaaaaaX9AKaaaaaaaaaa'
     'aaaaaaaaaabVyqaaaaaaaaaaaaaaaaaaaaYu7KaaaaaaaaaaaaaaaaaaaaXu7Caaaaaaaaaa'
     'aaaaaaaaaaaNwaaaaaaaaaaaaaaaaaaaaaaYKaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
     'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
     'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
     'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
    ),
    (((99, 97, 112), (65, 63, 82), (52, 49, 69), (44, 41, 63), (44, 41, 62), (44, 41, 61), (43, 41, 62), (41, 38, 60)),
     'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
     'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
     'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
     'aaaaaaaaaaa+taaaaaaaaaaaaaaaaaaaaaaIIaaaaaaaaaaaaaaaaaaaaav99Faaaaaaaaaa'
     'aaaaaaaaaaPe7BaaaaaaaaaaaaaaaaaaaaP81BaaaaaaaaaaaaaaaaaaaaP/1Baaaaaaaaaa'
     'aaaaaaaaaav99FaaaaaaaaaaaaaaaaaaaapIIUaaaaaaaaaaaaaaaaaaaaa//aaaaaaaaaaa'
     'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
     'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
     'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
    ),
)
CLIP_CODES="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz+/"

def clip_frame(palette,data,deadline):
    offset=0
    for row in range(27):
        run=0
        previous=-1
        for x in range(48):
            if x%2==0:
                pair=CLIP_CODES.index(data[offset])
                offset+=1
                pixel=pair//8
            else:
                pixel=pair%8
            if pixel!=previous:
                if x:
                    box(palette[previous],16+run*6,12+row*6,(x-run)*6,6)
                run=x
                previous=pixel
        box(palette[previous],16+run*6,12+row*6,(48-run)*6,6)
        if get_key(0) in (OK,EXIT) or monotonic()>=deadline:
            return False
    return True

def intro():
    start=monotonic()
    deadline=start+20
    box(INK,0,0,320,210)
    label(MILK,16,201,"ENTER skip / 20-second intro")
    shown=-1
    while True:
        if get_key(0) in (OK,EXIT):
            return
        elapsed=monotonic()-start
        if elapsed>=20:
            return
        index=int(elapsed//2)
        if index!=shown:
            if not clip_frame(CLIP[index][0],CLIP[index][1],deadline):
                return
            box(STEEL,16,180,288,5)
            box(MINT,16,180,28*(index+1),5)
            shown=index

def front_menu():
    from EVOVIEW import person
    intro()
    settings=[False,1,True]
    items=("New story","Load save","Settings","Quit")
    selected=0
    while True:
        skyline(7)
        box((51,91,121),0,84,320,53)
        for x in (149,194,242,287):
            box((123,146,174),x,100+x%9,23,2)
        box(VIOLET,0,133,320,77)
        box(STEEL,132,138,188,3)
        for x in (147,219,291):
            box(STEEL,x,138,3,59)
        person(193,190,121,MINT,0,False)
        person(258,190,133,BLUE,0,False)
        box(INK,0,0,133,210)
        label(SUN,8,27,"LAST LIGHT")
        label(MINT,8,48,"COASTLINE")
        for i,item in enumerate(items):
            y=72+24*i
            if i==selected:
                box(PINK,4,y-14,3,15)
            label(MILK if i==selected else STEEL,10,y,item)
        label(MINT,8,181,"V13 CLIP")
        label(MILK,8,202,"ENTER select")
        key=keywait((UP,DOWN,OK,MAP,EXIT))
        if key==EXIT or (key==OK and selected==3):
            return EXIT,settings
        if key==MAP or (key==OK and selected==1):
            return MAP,settings
        if key==OK:
            if selected==0:
                return OK,settings
            menu_settings(settings)
        else:
            selected=(selected+(1 if key==DOWN else -1))%4

def menu_settings(settings):
    row=0
    while True:
        labels=("Graphics  "+("Full" if settings[0] else "Fast"),
                "Turning   "+("Fine","Normal","Sharp")[settings[1]],
                "View      "+("3D" if settings[2] else "Top-down"))
        lines=tuple(("> " if i==row else "  ")+item
                    for i,item in enumerate(labels))
        sheet("SETTINGS",lines,"ARROWS change / CLEAR back")
        key=keywait((UP,DOWN,LEFT,RIGHT,OK,EXIT))
        if key==EXIT:
            return
        if key in (UP,DOWN):
            row=(row+(1 if key==DOWN else -1))%3
        elif row==1:
            settings[1]=(settings[1]+(-1 if key==LEFT else 1))%3
        else:
            settings[row]=not settings[row]
