PALETTE=((0, 0, 0),)
RECTS=(
'AADRE',
)
