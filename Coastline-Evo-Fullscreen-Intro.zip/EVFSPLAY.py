import gc
import sys
import ti_draw as draw
from ti_system import get_key
from time import monotonic

CODES="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
SLOTS=(0,4,6,8,10,12,14,16,18)

def frame(module,decode,deadline):
    x_edges=[i*320//104 for i in range(105)]
    y_edges=[i*210//68 for i in range(69)]
    for rgb,rectangles in zip(module.PALETTE,module.RECTS):
        draw.set_color(*rgb)
        for i in range(0,len(rectangles),5):
            value=(decode[rectangles[i]]<<24)|(decode[rectangles[i+1]]<<18)
            value|=(decode[rectangles[i+2]]<<12)|(decode[rectangles[i+3]]<<6)
            value|=decode[rectangles[i+4]]
            x=value>>21
            y=(value>>14)&127
            width=(value>>7)&127
            height=value&127
            left=x_edges[x]
            top=y_edges[y]
            draw.fill_rect(left-1,top-1,x_edges[x+width]-left+1,y_edges[y+height]-top+1)
            if i%160==0 and (get_key(0) in (45,105) or monotonic()>=deadline):
                return False
    return True

def play():
    decode={c:i for i,c in enumerate(CODES)}
    start=monotonic()
    deadline=start+20
    for index,timestamp in enumerate(SLOTS):
        next_time=start+(SLOTS[index+1] if index+1<len(SLOTS) else 20)
        if monotonic()>=deadline or get_key(0) in (45,105):
            return True
        if monotonic()>=next_time:
            continue
        name="EVFS%03d"%timestamp
        gc.collect()
        try:
            module=__import__(name)
        except (ImportError,MemoryError):
            return False
        complete=frame(module,decode,deadline)
        del module
        if name in sys.modules:
            del sys.modules[name]
        if not complete:
            return True
        while monotonic()<next_time:
            if get_key(0) in (45,105):
                return True
    return True
