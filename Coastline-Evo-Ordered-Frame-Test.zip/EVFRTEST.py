import gc
import sys
import ti_draw as draw
from ti_system import get_key
from time import monotonic

CODES="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

def frame(module):
    # Each rectangle stores x, y, width and height as four packed values.
    decode={c:i for i,c in enumerate(CODES)}
    for rgb,rectangles in zip(module.PALETTE,module.RECTS):
        draw.set_color(*rgb)
        for i in range(0,len(rectangles),5):
            value=(decode[rectangles[i]]<<24)|(decode[rectangles[i+1]]<<18)
            value|=(decode[rectangles[i+2]]<<12)|(decode[rectangles[i+3]]<<6)
            value|=decode[rectangles[i+4]]
            x=value>>21
            y=(value>>14)&127
            width=(value>>7)&127
            height=value&127
            draw.fill_rect(39+x*2,19+y*2,1+width*2,1+height*2)
            if i%160==0 and get_key(0)==45:
                return False
    return True

def play():
    draw.set_color(24,23,38)
    draw.fill_rect(-1,-1,321,211)
    draw.set_color(255,255,255)
    draw.draw_text(40,185,"CLEAR exits the test")
    longest=0
    for name in ('EVFR000', 'EVFR004', 'EVFR006', 'EVFR008', 'EVFR010', 'EVFR012', 'EVFR014', 'EVFR016', 'EVFR018'):
        gc.collect()
        start=monotonic()
        try:
            module=__import__(name)
        except (ImportError,MemoryError) as error:
            print(name,error)
            return
        if not frame(module):
            return
        del module
        if name in sys.modules:
            del sys.modules[name]
        elapsed=monotonic()-start
        longest=max(longest,elapsed)
        until=monotonic()+1
        while monotonic()<until:
            if get_key(0)==45:
                return
    draw.set_color(24,23,38)
    draw.fill_rect(-1,-1,321,211)
    draw.set_color(255,255,255)
    draw.draw_text(10,66,"9 clip frames displayed")
    draw.draw_text(10,98,"Slowest load + draw:")
    draw.draw_text(10,130,"%d ms"%round(longest*1000))
    draw.draw_text(10,175,"ENTER or CLEAR exits")
    while get_key(0) not in (45,105):
        pass

play()
