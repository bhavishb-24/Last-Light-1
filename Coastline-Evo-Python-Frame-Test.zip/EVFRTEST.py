import gc
import sys
import ti_draw as draw
from ti_system import get_key
from time import monotonic

CODES="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

def frame(module):
    palette=module.PALETTE
    pixels=module.PIXELS
    word=0
    bits=0
    index=0
    for y in range(68):
        left=0
        last=-1
        for x in range(121):
            pixel=-1
            if x<120:
                if bits<5:
                    word=(word<<6)|CODES.index(pixels[index])
                    index+=1
                    bits+=6
                bits-=5
                pixel=word>>bits
                word&=(1<<bits)-1
            if pixel!=last:
                if x:
                    r,g,b=palette[last]
                    draw.set_color(r,g,b)
                    draw.fill_rect(39+left*2,19+y*2,1+(x-left)*2,3)
                left=x
                last=pixel
        if get_key(0)==45:
            return False
    return True

def play():
    draw.set_color(24,23,38)
    draw.fill_rect(-1,-1,321,211)
    draw.set_color(255,255,255)
    draw.draw_text(40,185,"CLEAR exits the test")
    longest=0
    for name in ("EVFR009","EVFR010","EVFR011"):
        gc.collect()
        start=monotonic()
        try:
            module=__import__(name)
        except (ImportError,MemoryError) as error:
            print(name,error)
            return
        if not frame(module):
            return
        del module
        if name in sys.modules:
            del sys.modules[name]
        elapsed=monotonic()-start
        longest=max(longest,elapsed)
        until=monotonic()+1
        while monotonic()<until:
            if get_key(0)==45:
                return
    draw.set_color(24,23,38)
    draw.fill_rect(-1,-1,321,211)
    draw.set_color(255,255,255)
    draw.draw_text(10,66,"3 clip frames displayed")
    draw.draw_text(10,98,"Slowest load + draw:")
    draw.draw_text(10,130,"%d ms"%round(longest*1000))
    draw.draw_text(10,175,"ENTER or CLEAR exits")
    while get_key(0) not in (45,105):
        pass

play()
